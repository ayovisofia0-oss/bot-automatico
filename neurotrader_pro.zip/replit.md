# NEUROTRADER PRO — IQ Option Bot v3.0

## Descripción
Bot de trading automático para IQ Option con Streamlit. Opera opciones binarias/digitales de 1 minuto con análisis técnico multi-estrategia y sistema de Martingala.

## Arquitectura
- `main.py` — Interfaz Streamlit (sidebar credenciales, controles, estadísticas)
- `bot_engine.py` — Motor principal: análisis, ejecución de trades, loop de escaneo
- `license_manager.py` — Sistema de licencias
- `licencias.json` — Base de datos de licencias
- `pages/1_🔑_Gestor_Licencias.py` — Página admin de licencias
- `.streamlit/config.toml` — Configuración de tema Streamlit

## Stack
- Python 3.11, Streamlit, Pandas, NumPy, ta (indicadores técnicos)
- iqoptionapi (websocket IQ Option)
- Plotly (gráficos)

## Ejecutar
```
streamlit run main.py --server.port 5000 --server.address 0.0.0.0
```

## Modificaciones aplicadas (spec 30-Mar-2026)

### 1. Estrategias reemplazadas (13 → 3)
Las 13 estrategias originales fueron reemplazadas por 3 nuevas en `bot_engine.py`:

| Clave | Nombre | Ponderación | Descripción |
|-------|--------|-------------|-------------|
| `bollinger` | Bollinger+EMA (Volátil) | 2 pts | Solo en mercados VOLATILE. Rebote en banda BB + confirmación EMA50/100 en 15min |
| `lineas` | Líneas Tendencia (2+ toques) | 1 pt | Trendlines con ≥2 toques previos; señal en 3er acercamiento |
| `sop_res` | S/R Fuerte (3er toque) | 3 pts | Zonas horizontales con ≥3 toques; señal en rebote confirmado |

**Regla de consenso**: Se requieren **≥2 estrategias en acuerdo** para generar señal.

### 2. Martingala — disparo inmediato
Antes: esperaba al inicio del siguiente minuto (`no_antes_de = siguiente_minuto + s01`).
Ahora: dispara **2 segundos después** de confirmar la pérdida (`no_antes_de = ahora + 2s`).
Multiplicadores: Nv1 = 2.5×, Nv2 = 6× (sin cambio).

### 3. Escáner continuo
- `PAUSA_ENTRE_LOTES = 2` segundos (antes 30 s)
- `MAX_CONCURRENT_TRADES = 2` (antes 1)
- El escáner analiza todos los activos en rondas continuas sin pausas largas.

### 4. Helpers añadidos
- `obtener_tendencia_15min(api, asset)` — EMA50 vs EMA100 en velas de 15 min; TTL 5 min
- `clasificar_tipo_mercado(df)` — Clasifica en VOLATILE / QUIET / NORMAL según anchura BB y tamaño de velas

## Invariantes (NO modificar)
- Lógica de conexión a IQ Option (`intentar_reconexion`, websockets)
- Sistema de envío de órdenes (`ejecutar_trade`, `_disparar_señal`)
- Infraestructura UI Streamlit (layout, autenticación, licencias)
- `_scan_lock`, `_velas_cache` (thread safety del escáner)
